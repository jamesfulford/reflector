
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Mapping between integers and words. (This is a hash map)
 * @author James
 */
public class language {
    String[] words;
    
    public language(File extractionPoint) throws FileNotFoundException{
        Scanner type = new Scanner ( extractionPoint );
        String s = "";
        while(type.hasNextLine()){
            s = s + String.valueOf( (char) 182 ) + type.nextLine();
        }
        StringList temp = listAllWords(s);
        words = temp.toArray();
        type.close();
    }
    
    public language(String[] s){
        words = s;
    }
    
    
    public void uniqueize(){
        StringList uniques = new StringList(1000);
        
        for(int i = 0; i < words.length; i++){ //go through all the words
            boolean addToList = true;
            for(int k = 0; k < uniques.top; k++){ //check for same
                
                if( words[i].equalsIgnoreCase( uniques.map[k] ) ){
                    addToList=false;
                    break;
                }
            }
            if(addToList) uniques.add(words[i]);
        }
        
        words = uniques.toArray();
    }
    
    public void print(){
        System.out.println();
        for(int i = 0; i < words.length; i++)
            System.out.println( words[i] );
    }
    
    public StringList listAllWords(String s){
        StringList words = StringList.init(10000);
        
        char[] array = s.toCharArray();
        int d = 0;
        
        CharStack workStack = CharStack.init();
        
        while(d < array.length){
            if(endOfWord(array[d])){
               words.add( workStack.flush() );
            }
            
            workStack.push(cast(array[d]));
            d++;
            }
        return words;
    }
    
    private boolean endOfWord(char a){
        if((int) a < 127 && (int) a > 32){
            if(a == '"' || a == '.' || a == ',' || a == '?' || a == '!') return true;
        
            return false;
        }
        return true;  
    }
    //returns true if the character indicates the end of a word.

    private char cast(char a){
       int v = (int) a;
       if( v == 13 ) return (char) 182;
       if( v <= 32 ) return (char) '_';
//       if( v == 32) return '_';
       if( v > 32 && v <=126 ) return a;
       
       return '_';
    }
    //returns a more visible character for invisible characters. Otherwise returns input.
}